figure
TT = actxcontrol('TTank.X');
invoke(TT, 'ConnectServer', 'Local','MyClient')
%location of the recording data
invoke(TT, 'OpenTank', 'F:\RECORDING\121009\121009', 'R')
invoke(TT,'SelectBlock','CH23-1')
invoke(TT,'CreateEpocIndexing')
M=TT.ReadEventsV(100000, 'Rate', 0,0,0.0, 0.0, 'All'); %Beware, in the old recording, Fram acually records LED timing. No Frame avaiable.
Time = invoke(TT,'ParseEvInfoV', 0, M, 6);
Rate = invoke(TT,'ParseEvInfoV', 0, M, 7);
M=TT.ReadEventsV(100000, 'LDur', 0,0,0.0, 0.0, 'All');
Dur = invoke(TT,'ParseEvInfoV', 0, M, 7);
Time_diff = diff(Time);
Index = 1:length(Time);
LightOff = [Time(Time_diff>1), Time(end)];
[row, Rate_index] = find(Time_diff>1);
Rate_index = [Rate_index, length(Time)];
LightOn = [Time(1); Time(Index(Time_diff>1)+1)'];
All = [round(Dur(Rate_index))', round(Rate(Rate_index))',  round(25*LightOn), round(25*LightOff)'];

%create a bAnn file associated with the video. put the light
%information into the first stream
%leave the second stream for behavior annotation

%location of the video
Filename = 'J:\121009\121009_CH23_Block1_C57fe1_s';
config = 'F:\Dayu\viral activation\viral acitvation config.txt';
% nStream 2
% 
% other o
% light l 
% control c
% freeze f
% dart d
% jump j

sr=seqIo(Filename,'r');
info = sr.getinfo();
A = behaviorData('create', config, info.numFrames);
types = A.getTypes();
names = A.getNames();
nFrame = A.nFrame(); 
ID1 = strfind_part(names, {'light'});
ID2 = strfind_part(names, {'other'});
ID3 = strfind_part(names, {'control'});
    
LL=All(:,3:4);

A.setStrm(1)
for i = 1:length(LL(:,1))
    if nFrame >LL(i,2);
        A.add(ID3, LL(i,1)-(LL(i,2)-LL(i,1)))
        A.add(ID1, LL(i,1))
        A.add(ID2, LL(i,2))
    end
end

A.setStrm(2)
for i = 1:length(LL(:,1))
    if nFrame >LL(i,2);
        A.add(ID3, LL(i,1)-(LL(i,2)-LL(i,1)))
        A.add(ID1, LL(i,1))
        A.add(ID2, LL(i,2))
    end
end

bAnnFile = [Filename, '.bAnn'];
A.save(bAnnFile)