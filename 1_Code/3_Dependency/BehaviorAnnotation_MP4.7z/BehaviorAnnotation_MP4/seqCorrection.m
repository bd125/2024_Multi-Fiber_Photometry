function diffFrame = seqCorrection(fNameR, fNameW, N1, N2)
% This program rewrites the sequence file to correct the dropped frame during recording
% diffFrame = seqCorrection('C:\Dayu Lin\Data\Recording\120221\120221_PFC1_top1', 'C:\Dayu Lin\Data\Recording\120221\120221_PFC1_top1_fixed')
% diffFrame reports the number of frames skipped by sequence file (positive
% number). Occasionally, diffFrame will be negative, indicating extra frames
% are recorded. 

sr = seqIo( fNameR, 'reader' );
info = sr.getinfo();
N = info.numFrames;
TS = sr.getts();
RL = TS(info.numFrames -1)-TS(1);
info = sr.getinfo();
info.fps = 24.988805015673908;  %this is the frame rate calculated from the electrophysiology recording 'Fram'
ds = 1/info.fps;
info.numFrames = round(RL*info.fps);
diffFrame = info.numFrames-N;
if abs(diffFrame)>1
    TS_new = TS(1):ds:TS(1)+(info.numFrames-1)*ds;
    switch info.codec
        case {'imageFormat103'}, info.codec = 'imageFormat201';
        case {'imageFormat102'}, info.codec = 'imageFormat102'; 
    end
    sw = seqIo( fNameW, 'writer', info);
    if nargin ==2, N1 =1; N2=info.numFrames;end
    if nargin ==3, N2 = info.numFrames; end
    for i =N1:N2
        [C, Ind]=min(abs(TS-TS_new(i)));
        sr.seek(Ind)
        I=sr.getframe();
        sw.addframe(I, TS_new(i));
    end
else
    copyfile(fNameR, fNameW)    
end

sw.close();
sr.close();
fclose('all')