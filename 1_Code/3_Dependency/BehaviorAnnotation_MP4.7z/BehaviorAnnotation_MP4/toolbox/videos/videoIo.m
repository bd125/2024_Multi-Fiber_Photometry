function out = videoIo( fName , action, varargin )
% 
switch lower(action)
  case {'reader','r'}, out = reader( fName, varargin{:} );
  case {'writer','w'}, out = writer( fName, varargin{:} );
  case 'getinfo', out = getInfo( fName );
  case 'crop', crop( fName, varargin{:} ); out=1;
  case 'toimgs', out = toImgs( fName, varargin{:} );
  case 'frimgs', frImgs( fName, varargin{:} ); out=1;
  case 'convert', convert( fName, varargin{:} ); out=1;
  case 'newheader', newHeader( fName, varargin{:} ); out=1;
  case {'readerdual','rdual'}, out=readerDual(fName,varargin{:});
  case 'roi', roi( fName, varargin{:}); out =1; 
  otherwise, error('seqIo unknown action: ''%s''',action);
end
function sr = reader( fName, cache )
if(nargin<2 || isempty(cache)), cache=0; end
if( cache>0 ), [as fs Is ts inds]=deal([]); end
v=VideoReader(fName);
r=@videoReaderPlugin; 
s=r('open',int32(-1),fName);
sr = struct( 'close',@() r('close',s), 'getframe',@getframe, ...
  'getframeb',@() r('getframeb',s), 'getts',@() r('getts',s), ...
  'getinfo',@() r('getinfo',s), 'getnext',@() r('getnext',s), ...
  'next',@() r('next',s), 'seek',@(f) r('seek',s,f), ...
  'step',@(d) r('step',s,d));
end

function info = getInfo( fName )
% See also seqIo
sr=reader(fName); info=sr.getinfo(); sr.close();
end

function sr = readerDual( fNames, cache )
% See also seqIo, seqIo>reader
if(nargin<2 || isempty(cache)), cache=0; end
s1=reader(fNames{1}, cache); i1=s1.getinfo();
s2=reader(fNames{2}, cache); i2=s2.getinfo();
info=i1; info.width=i1.width+i2.width;
if( i1.width~=i2.width || i1.height~=i2.height )
  s1.close(); s2.close(); error('Mismatched videos'); end
if( i1.numFrames~=i2.numFrames )
  warning('seq files of different lengths'); end %#ok<WNTAG>
frame2=@(f) round(f/(i1.numFrames-1)*(i2.numFrames-1));

sr=struct('close',@() min(s1.close(),s2.close()), ...
  'getframe',@getframe, 'getinfo',@() info, ...
  'seek',@(f) s1.seek(f) & s2.seek(frame2(f)) );

  function [I,t] = getframe()
    [I1,t]=s1.getframe(); I2=s2.getframe(); I=[I1 I2]; end
end

end
