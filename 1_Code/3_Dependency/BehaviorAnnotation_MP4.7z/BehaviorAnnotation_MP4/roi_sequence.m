fName = '\\linserver\Shared Lab Space\LW (grad)\LV ChR2 animals\Place preference\130703_LV17_PPstimsham20sinprefercham.seq';
fName_roi = '\\linserver\Shared Lab Space\LW (grad)\LV ChR2 animals\Place preference\130703_LV17_PPstimsham20sinprefercham_roi.seq';

sr = seqIo(fName, 'reader' );
sr.seek(3381);
I=sr.getframe();
figure; imagesc(I); colormap(gray);

h = impoly;
pos = getPosition(h);
seqIo(fName,'roi', fName_roi, pos);

