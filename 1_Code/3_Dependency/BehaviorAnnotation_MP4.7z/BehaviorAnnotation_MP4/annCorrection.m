function diffFrame = annCorrection(annName, annName_new, seqName)
% This program correct the time shifted in the behavior annotation file due to drop of frames
% diffFrame = annCorrection('111128_PFC1_side1_120109_BC.txt', '111128_PFC1_side1_120109_BC_fix.txt', '111128_PFC1_side1.seq' )
% please make sure that you set the current folder in the matlab as where the files are located or type the full name
% diffFrame reports the number of frames skipped by sequence file (positive
% number). Occasionally, diffFrame will be negative, indicating extra frames
% are recorded. 

sr = seqIo( seqName, 'reader' );
info = sr.getinfo();
N = info.numFrames;
TS = sr.getts();
RL = TS(info.numFrames -1)-TS(1);
info = sr.getinfo();
info.fps = 24.988805015673908;  %this is the correct frame rate calculated from the electrophysiology recording 'Fram'
ds = 1/info.fps;
info.numFrames = round(RL*info.fps);
diffFrame = info.numFrames-N;
frameN =[];
if abs(diffFrame)>1
    TS_new = TS(1):ds:TS(1)+(info.numFrames-1)*ds;
    for i=1:N
        a = max(i-1000, 1);
        b = min(i+1000, info.numFrames);
        TS_temp = TS_new(a:b);
        [C, Id] = min(abs(TS(i)-TS_temp));
        frameN(i) = Id+a-1;
    end
    A = behaviorData('load', annName);
    B = A; 
    B.setStart(1)=0; B.setEnd(1) = frameN(A.getStart(1)+1)-1;
    for i =2:A.n()
        B.move(i,frameN(A.getEnd(i-1)+1)); 
    end
end

t=[annName_new '.txt']; if(exist(t,'file')), delete(t); end
B.save(annName_new)